﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        void ShowWindowFinal(int par)
        {
            Form2 form2 = new Form2(par);
            form2.ShowDialog();
  
        }

        public Form1()
        {
            InitializeComponent();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void btLula_Click(object sender, EventArgs e)
        {
            ShowWindowFinal(1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btBolsonaro_Click(object sender, EventArgs e)
        {
            ShowWindowFinal(2);
        }
    }
}
