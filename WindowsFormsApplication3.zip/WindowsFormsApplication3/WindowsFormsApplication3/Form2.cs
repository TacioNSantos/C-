﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {
        public Form2(int par)
        {
            InitializeComponent();

            if (par == 1)
            {
                picBox1.Image = (global::WindowsFormsApplication3.Properties.Resources.lula);
                lbVotoFinal.Text = "VOTO COMPUTADO!!";
            }
            else if (par == 2)
            {
                picBox1.Image = (global::WindowsFormsApplication3.Properties.Resources.bolsonaro);
                lbVotoFinal.Text = "VOTO COMPUTADO!!";
            }
         }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    
   }
}
