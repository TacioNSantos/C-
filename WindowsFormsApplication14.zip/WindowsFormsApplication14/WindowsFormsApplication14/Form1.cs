﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txFatorial_TextChanged(object sender, EventArgs e)
        {
            int valor = int.Parse(txFatorial.Text);
            int n = valor - 1;

            while (n != 0)
            {
                valor = valor * (n);
                n--;
               
            }
                MessageBox.Show("O fatorial é  " + valor);   
                MessageBox.Show("O fatorial não pode ser zero, o progama foi encerrado");
            
        }
    }
}
