﻿namespace WindowsFormsApplication14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbMensagem = new System.Windows.Forms.Label();
            this.txFatorial = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbMensagem
            // 
            this.lbMensagem.AutoSize = true;
            this.lbMensagem.Location = new System.Drawing.Point(137, 53);
            this.lbMensagem.Name = "lbMensagem";
            this.lbMensagem.Size = new System.Drawing.Size(219, 13);
            this.lbMensagem.TabIndex = 0;
            this.lbMensagem.Text = "Imforme o número que deseja obter o fatorial!";
            // 
            // txFatorial
            // 
            this.txFatorial.Location = new System.Drawing.Point(188, 87);
            this.txFatorial.Name = "txFatorial";
            this.txFatorial.Size = new System.Drawing.Size(100, 20);
            this.txFatorial.TabIndex = 1;
            this.txFatorial.TextChanged += new System.EventHandler(this.txFatorial_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 407);
            this.Controls.Add(this.txFatorial);
            this.Controls.Add(this.lbMensagem);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbMensagem;
        private System.Windows.Forms.TextBox txFatorial;
    }
}

