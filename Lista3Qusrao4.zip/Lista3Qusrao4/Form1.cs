using System.Media;

namespace Lista3Qusrao4
{
    public partial class Form1 : Form
    {
        int votoID1 = 0;
        int votoID2 = 0;
        int votoID3 = 0;
        int votoID4 = 0;
        int votoIDBranco = 0;
        int votoIDNulo = 0;
        int total = 0;
        float percemBranco, percemNulo = 0;

        

        public Form1()
        {
            InitializeComponent();
        }

        private void btFinalizar_Click(object sender, EventArgs e)
        {
            percemBranco = ((votoIDBranco * 100) / total);
            percemNulo = ((votoIDNulo * 100) / total);
            Form2 form2 = new Form2 (votoID1, votoID2, votoID3,votoID4, votoIDBranco, votoIDNulo, total, percemBranco, percemNulo);
            form2.ShowDialog();
            
        }

        private void btLula_Click(object sender, EventArgs e)
        {
            votoID1++;
            total++;
            
        }

        private void btBolsonaro_Click(object sender, EventArgs e)
        {
            votoID2++;
            total++;
        }

        private void btCiro_Click(object sender, EventArgs e)
        {
            votoID3++;
            total++;
        }

        private void btTebet_Click(object sender, EventArgs e)
        {
            votoID4++;
            total++;
        }

        private void btBranco_Click(object sender, EventArgs e)
        {
            votoIDBranco++;
            total++;
        }

        private void btSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btNulo_Click(object sender, EventArgs e)
        {
            votoIDNulo++;
            total++;
        }
    }
}