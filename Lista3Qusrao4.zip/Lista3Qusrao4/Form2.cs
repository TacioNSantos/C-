﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace Lista3Qusrao4
{
    public partial class Form2 : Form
    {
        public Form2(int votoID1, int votoID2, int votoID3, int votoID4, int votoIDBranco, int votoIDNulo, int total, float percenBranco, float percenNulo)
        {
            InitializeComponent();
            lbTotal.Text = ("O total de votos foi: " + total);
            lbCandidato1.Text = ("Lula: " + votoID1);
            lbBolsoanro.Text = ("Bolsonaro: " + votoID2);
            lbCiro.Text = ("Ciro: " + votoID3);
            lbTebet.Text = ("Tebet: " + votoID4);
            lbBranco.Text = ("O total de votor Brancos foi: " + votoIDBranco);
            lbNulo.Text = ("O total de votor Nulos foi: " + votoIDNulo);
            lbPorcenBranco.Text = ("O percentual de votos Brancos foi: " + percenBranco.ToString("F") + "%");
            lbPorcenNulo.Text = ("O percentual de votos Nulos foi: " + percenNulo.ToString("F")+ "%");
        }

        private void lbPorcenNulo_Click(object sender, EventArgs e)
        {

        }
    }
}
