﻿namespace Lista3Qusrao4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btLula = new System.Windows.Forms.Button();
            this.btBolsonaro = new System.Windows.Forms.Button();
            this.btCiro = new System.Windows.Forms.Button();
            this.btTebet = new System.Windows.Forms.Button();
            this.btBranco = new System.Windows.Forms.Button();
            this.btNulo = new System.Windows.Forms.Button();
            this.btFinalizar = new System.Windows.Forms.Button();
            this.btSair = new System.Windows.Forms.Button();
            this.picLula = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picLula)).BeginInit();
            this.SuspendLayout();
            // 
            // btLula
            // 
            this.btLula.Location = new System.Drawing.Point(554, 60);
            this.btLula.Name = "btLula";
            this.btLula.Size = new System.Drawing.Size(94, 29);
            this.btLula.TabIndex = 0;
            this.btLula.Text = "Lula";
            this.btLula.UseVisualStyleBackColor = true;
            this.btLula.Click += new System.EventHandler(this.btLula_Click);
            // 
            // btBolsonaro
            // 
            this.btBolsonaro.Location = new System.Drawing.Point(694, 60);
            this.btBolsonaro.Name = "btBolsonaro";
            this.btBolsonaro.Size = new System.Drawing.Size(94, 29);
            this.btBolsonaro.TabIndex = 1;
            this.btBolsonaro.Text = "Bolsonaro";
            this.btBolsonaro.UseVisualStyleBackColor = true;
            this.btBolsonaro.Click += new System.EventHandler(this.btBolsonaro_Click);
            // 
            // btCiro
            // 
            this.btCiro.Location = new System.Drawing.Point(554, 123);
            this.btCiro.Name = "btCiro";
            this.btCiro.Size = new System.Drawing.Size(94, 29);
            this.btCiro.TabIndex = 2;
            this.btCiro.Text = "Ciro";
            this.btCiro.UseVisualStyleBackColor = true;
            this.btCiro.Click += new System.EventHandler(this.btCiro_Click);
            // 
            // btTebet
            // 
            this.btTebet.Location = new System.Drawing.Point(694, 123);
            this.btTebet.Name = "btTebet";
            this.btTebet.Size = new System.Drawing.Size(94, 29);
            this.btTebet.TabIndex = 3;
            this.btTebet.Text = "Tebet";
            this.btTebet.UseVisualStyleBackColor = true;
            this.btTebet.Click += new System.EventHandler(this.btTebet_Click);
            // 
            // btBranco
            // 
            this.btBranco.BackColor = System.Drawing.SystemColors.Window;
            this.btBranco.Location = new System.Drawing.Point(554, 201);
            this.btBranco.Name = "btBranco";
            this.btBranco.Size = new System.Drawing.Size(94, 29);
            this.btBranco.TabIndex = 4;
            this.btBranco.Text = "Branco";
            this.btBranco.UseVisualStyleBackColor = false;
            this.btBranco.Click += new System.EventHandler(this.btBranco_Click);
            // 
            // btNulo
            // 
            this.btNulo.Location = new System.Drawing.Point(694, 201);
            this.btNulo.Name = "btNulo";
            this.btNulo.Size = new System.Drawing.Size(94, 29);
            this.btNulo.TabIndex = 5;
            this.btNulo.Text = "Nulo";
            this.btNulo.UseVisualStyleBackColor = true;
            this.btNulo.Click += new System.EventHandler(this.btNulo_Click);
            // 
            // btFinalizar
            // 
            this.btFinalizar.BackColor = System.Drawing.Color.Green;
            this.btFinalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btFinalizar.ForeColor = System.Drawing.Color.White;
            this.btFinalizar.Location = new System.Drawing.Point(541, 382);
            this.btFinalizar.Name = "btFinalizar";
            this.btFinalizar.Size = new System.Drawing.Size(117, 56);
            this.btFinalizar.TabIndex = 6;
            this.btFinalizar.Text = "FINALIZAR";
            this.btFinalizar.UseVisualStyleBackColor = false;
            this.btFinalizar.Click += new System.EventHandler(this.btFinalizar_Click);
            // 
            // btSair
            // 
            this.btSair.Location = new System.Drawing.Point(694, 382);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(94, 56);
            this.btSair.TabIndex = 7;
            this.btSair.Text = "Desligar";
            this.btSair.UseVisualStyleBackColor = true;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // picLula
            // 
            this.picLula.Image = global::Lista3Qusrao4.Properties.Resources.lula;
            this.picLula.Location = new System.Drawing.Point(51, 81);
            this.picLula.Name = "pictureBox1";
            this.picLula.Size = new System.Drawing.Size(340, 224);
            this.picLula.TabIndex = 8;
            this.picLula.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 450);
            this.Controls.Add(this.picLula);
            this.Controls.Add(this.btSair);
            this.Controls.Add(this.btFinalizar);
            this.Controls.Add(this.btNulo);
            this.Controls.Add(this.btBranco);
            this.Controls.Add(this.btTebet);
            this.Controls.Add(this.btCiro);
            this.Controls.Add(this.btBolsonaro);
            this.Controls.Add(this.btLula);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picLula)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Button btLula;
        private Button btBolsonaro;
        private Button btCiro;
        private Button btTebet;
        private Button btBranco;
        private Button btNulo;
        private Button btFinalizar;
        private Button btSair;
        private PictureBox picLula;
    }
}