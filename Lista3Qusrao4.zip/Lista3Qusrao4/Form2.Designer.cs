﻿namespace Lista3Qusrao4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbCandidato1 = new System.Windows.Forms.Label();
            this.lbTotal = new System.Windows.Forms.Label();
            this.lbBolsoanro = new System.Windows.Forms.Label();
            this.lbCiro = new System.Windows.Forms.Label();
            this.lbTebet = new System.Windows.Forms.Label();
            this.lbBranco = new System.Windows.Forms.Label();
            this.lbPorcenBranco = new System.Windows.Forms.Label();
            this.lbNulo = new System.Windows.Forms.Label();
            this.lbPorcenNulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbCandidato1
            // 
            this.lbCandidato1.AutoSize = true;
            this.lbCandidato1.Location = new System.Drawing.Point(54, 36);
            this.lbCandidato1.Name = "lbCandidato1";
            this.lbCandidato1.Size = new System.Drawing.Size(36, 20);
            this.lbCandidato1.TabIndex = 0;
            this.lbCandidato1.Text = "Lula";
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Location = new System.Drawing.Point(64, 458);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(42, 20);
            this.lbTotal.TabIndex = 1;
            this.lbTotal.Text = "Total";
            // 
            // lbBolsoanro
            // 
            this.lbBolsoanro.AutoSize = true;
            this.lbBolsoanro.Location = new System.Drawing.Point(178, 36);
            this.lbBolsoanro.Name = "lbBolsoanro";
            this.lbBolsoanro.Size = new System.Drawing.Size(76, 20);
            this.lbBolsoanro.TabIndex = 2;
            this.lbBolsoanro.Text = "Bolsonaro";
            // 
            // lbCiro
            // 
            this.lbCiro.AutoSize = true;
            this.lbCiro.Location = new System.Drawing.Point(54, 126);
            this.lbCiro.Name = "lbCiro";
            this.lbCiro.Size = new System.Drawing.Size(36, 20);
            this.lbCiro.TabIndex = 3;
            this.lbCiro.Text = "Ciro";
            // 
            // lbTebet
            // 
            this.lbTebet.AutoSize = true;
            this.lbTebet.Location = new System.Drawing.Point(195, 126);
            this.lbTebet.Name = "lbTebet";
            this.lbTebet.Size = new System.Drawing.Size(46, 20);
            this.lbTebet.TabIndex = 4;
            this.lbTebet.Text = "Tebet";
            // 
            // lbBranco
            // 
            this.lbBranco.AutoSize = true;
            this.lbBranco.Location = new System.Drawing.Point(51, 341);
            this.lbBranco.Name = "lbBranco";
            this.lbBranco.Size = new System.Drawing.Size(55, 20);
            this.lbBranco.TabIndex = 6;
            this.lbBranco.Text = "Branco";
            // 
            // lbPorcenBranco
            // 
            this.lbPorcenBranco.AutoSize = true;
            this.lbPorcenBranco.Location = new System.Drawing.Point(614, 370);
            this.lbPorcenBranco.Name = "lbPorcenBranco";
            this.lbPorcenBranco.Size = new System.Drawing.Size(112, 20);
            this.lbPorcenBranco.TabIndex = 8;
            this.lbPorcenBranco.Text = "lbPorcenbranco";
            // 
            // lbNulo
            // 
            this.lbNulo.AutoSize = true;
            this.lbNulo.Location = new System.Drawing.Point(54, 269);
            this.lbNulo.Name = "lbNulo";
            this.lbNulo.Size = new System.Drawing.Size(41, 20);
            this.lbNulo.TabIndex = 9;
            this.lbNulo.Text = "Nulo";
            // 
            // lbPorcenNulo
            // 
            this.lbPorcenNulo.AutoSize = true;
            this.lbPorcenNulo.Location = new System.Drawing.Point(614, 332);
            this.lbPorcenNulo.Name = "lbPorcenNulo";
            this.lbPorcenNulo.Size = new System.Drawing.Size(98, 20);
            this.lbPorcenNulo.TabIndex = 10;
            this.lbPorcenNulo.Text = "lbPorcenNulo";
            this.lbPorcenNulo.Click += new System.EventHandler(this.lbPorcenNulo_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 520);
            this.Controls.Add(this.lbPorcenNulo);
            this.Controls.Add(this.lbNulo);
            this.Controls.Add(this.lbPorcenBranco);
            this.Controls.Add(this.lbBranco);
            this.Controls.Add(this.lbTebet);
            this.Controls.Add(this.lbCiro);
            this.Controls.Add(this.lbBolsoanro);
            this.Controls.Add(this.lbTotal);
            this.Controls.Add(this.lbCandidato1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbCandidato1;
        private Label lbTotal;
        private Label lbBolsoanro;
        private Label lbCiro;
        private Label lbTebet;
        private Label lbBranco;
        private Label lbPorcenBranco;
        private Label lbNulo;
        private Label lbPorcenNulo;
    }
}